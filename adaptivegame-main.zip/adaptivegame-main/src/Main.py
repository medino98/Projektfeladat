from GameMaster import GameMaster


import time
import numpy as np



if __name__ == "__main__":
    gm = GameMaster()
    gm.run()
